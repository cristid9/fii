import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class ItemForm extends JPanel {

    private Map<String, JComponent> components;

    public ItemForm() {
        components = new HashMap<>();

        JPanel panel = new JPanel();
        this.setLayout(new GridLayout(4, 2));

        SpinnerModel model = new SpinnerNumberModel(1950, 1900, 2017, 1);

        components.put("name", new JTextField("Name"));
        components.put("path", new JTextField("Path"));
        components.put("year", new JSpinner(model));
        components.put("add", new JButton("Add"));

        this.add(components.get("name"));
        this.add(components.get("path"));

        this.add(components.get("year"));
        this.add(components.get("add"));
    }


    public Map<String, JComponent> getComponentsMap() {
        return components;
    }
}
