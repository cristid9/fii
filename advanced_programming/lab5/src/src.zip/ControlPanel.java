import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class ControlPanel extends JPanel {
    Map<String, JComponent> components;

    public ControlPanel() {
        components = new HashMap<>();

        this.setLayout(new GridLayout(1, 2));

        components.put("save", new JButton("Save"));
        components.put("exit", new JButton("Exit"));

        this.add(components.get("save"));
        this.add(components.get("exit"));
    }

    public Map<String, JComponent> getComponentsMap() {
        return components;
    }
}
