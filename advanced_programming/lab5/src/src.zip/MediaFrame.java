import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MediaFrame extends JFrame {
    public static void main(String[] args) {
        MediaFrame frame = new MediaFrame();
        frame.setLayout(new GridLayout(3, 2));


        ItemForm p1 = new ItemForm();
        CatalogList p2 = new CatalogList();
        ControlPanel p3 = new ControlPanel();

        frame.add(p1);
        frame.add(p2);
        frame.add(p3);

        ((JButton)p1.getComponentsMap().get("add")).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                p2.addItem(
                        ((JTextField)p1.getComponentsMap().get("name")).getText() + " " +
                        ((JTextField)p1.getComponentsMap().get("path")).getText() + " " +
                                String.valueOf(((JSpinner)p1.getComponentsMap().get("year")).getValue())
                );
            }
        });

        ((JButton)p3.getComponentsMap().get("save")).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.out.println("Se salveaza sefu! Solo.");
            }
        });


        ((JButton)p3.getComponentsMap().get("exit")).addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                frame.setVisible(false);
            }
        });

        frame.pack();
        frame.setVisible(true);
    }

}
