import javax.swing.*;
import java.util.HashMap;
import java.util.Map;

public class CatalogList extends JPanel {
    DefaultListModel<String> model = new DefaultListModel<>();

    Map<String, JComponent> components;

    public CatalogList() {
        components = new HashMap<>();

//        this.setLayout(new ScrollPaneLayout());
        this.setBorder(BorderFactory.createTitledBorder("Catalog Items"));
        model.addElement("------------------------------------------------------------------------------------------");


        JList list = new JList<String>(model);
        components.put("list", new JScrollPane(list));

        this.add(components.get("list"));

    }
    public void addItem(String item) {
        model.addElement(item);
    }

    public Map<String, JComponent> getComponentsList() {
        return components;
    }
}
