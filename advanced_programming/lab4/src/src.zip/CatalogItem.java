
public interface CatalogItem {
    void setItemName(String name);
    String getItemName();

    String getItemPath();
    void setItemPath(String name);

    String toString();
}
