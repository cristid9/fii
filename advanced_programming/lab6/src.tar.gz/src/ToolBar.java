import javax.swing.*;

/**
 * Created by cristi on 25.04.2017.
 */
public class ToolBar extends JPanel {
}
